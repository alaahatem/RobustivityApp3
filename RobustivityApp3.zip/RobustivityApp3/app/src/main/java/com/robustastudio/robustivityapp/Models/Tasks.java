package com.robustastudio.robustivityapp.Models;

import android.text.format.DateFormat;

import java.util.Date;

/**
 * Created by hp on 28/03/2018.
 */

public class Tasks {

public String name ;
public String title ;
public String description;
public String assigne ;
public String [] members;
public double estimated_hours;
public DateFormat due_date;
public DateFormat finished_hours;
public DateFormat StartDate ;

}
