package com.robustastudio.robustivityapp.Models;

/**
 * Created by hp on 28/03/2018.
 */

public class Sectors {
    public String name ;
    public String [] accounts ;

    public String[] getAccounts() {
        return accounts;
    }

    public void setAccounts(String[] accounts) {
        this.accounts = accounts;
    }

    public String getName() {

        return name;
    }
}
