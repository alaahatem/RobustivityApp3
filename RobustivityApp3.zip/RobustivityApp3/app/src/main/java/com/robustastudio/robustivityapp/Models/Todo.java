package com.robustastudio.robustivityapp.Models;

import java.text.DateFormat;
import java.util.Timer;

/**
 * Created by hp on 28/03/2018.
 */

public class Todo {

    public String [] members;
    public int  starttime;
    public DateFormat Date;
    public int Duration;

}
