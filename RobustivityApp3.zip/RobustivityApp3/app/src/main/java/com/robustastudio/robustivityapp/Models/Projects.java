package com.robustastudio.robustivityapp.Models;

import org.w3c.dom.Text;

import java.text.DateFormat;

/**
 * Created by hp on 28/03/2018.
 */

public class Projects {
    public String name ;
    public String type;
    public String [] engagement;
    public DateFormat StartDate;
    public  DateFormat endDate;
    public String Tagline;
    public String SectorName;
    public String accountName ;
    public double project_cost;

}
